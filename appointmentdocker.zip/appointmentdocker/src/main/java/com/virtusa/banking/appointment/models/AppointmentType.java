package com.virtusa.banking.appointment.models;

public enum AppointmentType {
  Loan,KYC,Savings,Demat
}
